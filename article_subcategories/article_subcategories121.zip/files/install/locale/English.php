<?php
//index.php
$locale['install_101'] = "Articles subcategories";
$locale['install_102'] = "This script will install subcategories for articles.";
$locale['install_103'] = "This script will uninstall subcategories for articles.";
$locale['install_104'] = "Install";
$locale['install_105'] = "Uninstall";
$locale['install_106'] = "Really want to remove subcategories for articles?";
$locale['install_107'] = "Return to site";
$locale['install_108'] = "Result - install";
$locale['install_108a'] = "Result - uninstall";
$locale['install_109'] = "Mod successfully installed! Immediately delete this folder.";
$locale['install_110'] = "Mod successfully uninstalled! Immediately delete this folder.<br />Put the original files on host!";
$locale['install_111'] = "WARNING: Only for superadmins!";
$locale['install_112'] = "Install file not found!";
?>
