<?php
$locale['400'] = "Articles";
$locale['401'] = "No Article Categories defined";
$locale['402'] = "NEW";
$locale['403'] = "No Articles have been added to this Category";
$locale['404'] = "Articles Home";
$locale['405'] = "Articles Hierarchy";
$locale['406'] = "Subcategories";//subarticles
?>