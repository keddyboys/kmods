<?php
$locale['400'] = "Web Links";
// Download File Information
$locale['410'] = "[NEW]";
$locale['411'] = "Date Added:";
$locale['412'] = "Visits:";
$locale['413'] = "Subcategories";//subweblinks
// Downloads Notices
$locale['430'] = "No Web Link Categories defined";
$locale['431'] = "No Web Links have been added to this Category";
?>