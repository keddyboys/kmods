<?php
$locale['400'] = "Leg&#259;turi pe Internet";
// Download File Information
$locale['410'] = "[NOU]";
$locale['411'] = "Data ad&#259;ug&#259;rii:";
$locale['412'] = "Vizite:";
$locale['413'] = "Subcategorii";//subweblinks
// Downloads Notices
$locale['430'] = "Nu exist&#259; categorii de leg&#259;turi pe internet definite.";
$locale['431'] = "Nu exist&#259; leg&#259;turi pe internet ad&#259;ugate &#238;n aceast&#259; categorie.";
?>