<?php
// Download Category titles
$locale['400'] = "Editare categorii desc&#259;rc&#259;ri";
$locale['401'] = "Adaug&#259; o categorie de desc&#259;rc&#259;ri";
$locale['402'] = "Categoriile actuale de desc&#259;rc&#259;ri";
// Download Category messages
$locale['410'] = "Categorie desc&#259;rc&#259;ri ad&#259;ugat&#259;";
$locale['411'] = "Categorie desc&#259;rc&#259;ri actualizat&#259;";
$locale['412'] = "Categoria de desc&#259;rc&#259;ri nu poate fi &#351;tears&#259;";
$locale['413'] = "Exist&#259; desc&#259;rc&#259;ri care apar&#355;in acestei categorii";
$locale['414'] = "Categorie desc&#259;rc&#259;ri &#351;tears&#259;";
// Download Category form
$locale['420'] = "Nume categorie:";
$locale['421'] = "Descriere categorie:";
$locale['422'] = "Sortare categorii:";
$locale['423'] = "ID desc&#259;rcare";
$locale['424'] = "Titlu desc&#259;rcare";
$locale['425'] = "Data desc&#259;rcare";
$locale['426'] = "Cresc&#259;tor";
$locale['427'] = "Descresc&#259;tor";
$locale['428'] = "Acces categorie:";
$locale['429'] = "Salveaz&#259; categoria";
$locale['430'] = "P&#259;rinte categorie:";//subdownloads
// Current Download Categories
$locale['440'] = "Categorie";
$locale['441'] = "Acces";
$locale['442'] = "Op&#355;iuni";
$locale['443'] = "Editeaz&#259;";
$locale['444'] = "&#350;terge";
$locale['445'] = "Nu exist&#259; categorii de desc&#259;rc&#259;ri definite";
// Delete Download category
$locale['450'] = "Sterg aceasta categorie?";
// Error Messages
$locale['460'] = "V&#259; rug&#259;m s&#259; introduce&#355;i un nume de categorie.";
$locale['461'] = "Aceast&#259; categorie exist&#259; deja.";
?>