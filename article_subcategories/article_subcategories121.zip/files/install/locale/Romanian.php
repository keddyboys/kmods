<?php
//index.php
$locale['install_101'] = "Subcategori la articole";
$locale['install_102'] = "Acest script va instala subcategoriile pentru articole.";
$locale['install_103'] = "Acest script va dezinstala subcategoriile pentru articole.";
$locale['install_104'] = "Esti sigur ca vrei sa stergi subcategoriile pentru articole?"; 
$locale['install_105'] = "Instaleaz&#259;";
$locale['install_106'] = "Dezinstaleaz&#259;";
$locale['install_107'] = "Revenire la sait";
$locale['install_108'] = "Rezultat - instalare";
$locale['install_108a'] = "Rezultat - dezinstalare";
$locale['install_109'] = "Mod instalat cu succes! &#350;terge imediat acest folder.";
$locale['install_110'] = "Mod dezinstalat cu succes! &#350;terge imediat acest folder.<br />Pune fi&#351;ierele originale pe host!";
$locale['install_111'] = "ATEN&#354;IE!: Trebuie sa fii Super Administrator!";
$locale['install_112'] = "Fi&#351;ierul de instalare nu exist&#259;!";
?>
