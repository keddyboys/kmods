<?php
$locale['400'] = "Albume foto";
$locale['401'] = "Deschide album";
$locale['402'] = "F&#259;r&#259; pictogram&#259; ";
$locale['403'] = "Data: ";
$locale['404'] = "Creat de: ";
$locale['405'] = "Fotografii: ";
$locale['406'] = "Nu exist&#259; albume foto definite.";
$locale['407'] = "Subalbume";//subphotos

$locale['420'] = "Informa&#355;ii album";
$locale['421'] = "Album: ";
$locale['422'] = "Num&#259;r de fotografii: ";
$locale['423'] = "Ultima imagine ad&#259;ugat&#259; de ";
$locale['424'] = " la ";
$locale['425'] = "Nu exist&#259; imagini &#238;n acest album.";

$locale['430'] = "Vizualizare album";
$locale['431'] = "Apas&#259; pentru vizualizare";
$locale['432'] = "F&#259;r&#259; pictogram&#259;";
$locale['433'] = "Data: ";
$locale['434'] = "Ad&#259;ugat&#259; de: ";
$locale['435'] = "Vizualiz&#259;ri: ";
$locale['436'] = "Comentarii: ";
$locale['436b'] = "Comentariu: ";
$locale['437'] = "Apreciere: ";
$locale['438'] = "Niciuna";

$locale['450'] = "Vezi poza";
$locale['451'] = "Poza anterioar&#259;";
$locale['452'] = "Poza urm&#259;toare";
$locale['453'] = "Apas&#259; pentru vedere integral&#259;";
$locale['454'] = "Dimensiuni: ";
$locale['455'] = "pixeli";
$locale['456'] = "Dimensiune fi&#351;ier: ";
$locale['457'] = "Num&#259;r de vizualiz&#259;ri: ";
$locale['458'] = "Apas&#259; pentru &#238;nchidere";
$locale['459'] = "Prima fotografie";
$locale['460'] = "Ultima fotografie";
?>