<?php
$locale['400'] = "Articole";
$locale['401'] = "Nu exist&#259; categorii de articole definite.";
$locale['402'] = "NOU";
$locale['403'] = "Nu a fost ad&#259;ugat niciun articol &#238;n aceast&#259; categorie.";
$locale['404'] = "Index articole";
$locale['405'] = "Ierarhie articole";
$locale['406'] = "Sub-categorii";//subarticles
?>