<?php
$locale['400'] = "Desc&#259;rc&#259;ri";
// Download File Information
$locale['410'] = "[NOU]";
$locale['411'] = "Licen&#355;&#259;:";
$locale['412'] = "Platforma:";
$locale['413'] = "Versiune:";
$locale['414'] = "Ad&#259;ugat:";
$locale['415'] = "Desc&#259;rc&#259;ri:";
$locale['416'] = "Descarc&#259;";
$locale['417'] = "Index desc&#259;rc&#259;ri";
$locale['418'] = "Pagina principal&#259;";
$locale['419'] = "Instantaneu";
$locale['420'] = "Titlu desc&#259;rcare";
$locale['421'] = "Dat&#259;";
$locale['422'] = "Autor";
$locale['423'] = "Versiune";
$locale['424'] = "Desc&#259;rc&#259;ri";
$locale['425'] = "Comentarii";
$locale['426'] = "Evalu&#259;ri";
$locale['427'] = "Calendar";
$locale['428'] = "Informa&#355;ii";
$locale['429'] = "Statistici desc&#259;rc&#259;ri";
// Downloads Notices
$locale['430'] = "Nu exist&#259; categorii de desc&#259;rc&#259;ri definite.";
$locale['431'] = "Nu exist&#259; desc&#259;rc&#259;ri ad&#259;ugate &#238;n aceast&#259; categorie.";
$locale['432'] = "Sub-categorii"; //subdownloads
// Statistics
$locale['440'] = "Desc&#259;rc&#259;ri efectuate:";
$locale['441'] = "Cel mai desc&#259;rcat:";
$locale['442'] = "Cel mai nou:";
// Search and filters
$locale['450'] = "Folose&#351;te filtrele din dreapta pentru a g&#259;si desc&#259;rc&#259;rile dorite";
$locale['451'] = "Toate";
$locale['452'] = "ID";
$locale['453'] = "Titlu";
$locale['454'] = "Autor";
$locale['455'] = "Desc&#259;rc&#259;ri";
$locale['456'] = "Dat&#259;";
$locale['457'] = "Cresc&#259;tor";
$locale['458'] = "Descresc&#259;tor";
$locale['459'] = "Salveaz&#259;";
$locale['460'] = "Caut&#259; desc&#259;rc&#259;ri:";
$locale['461'] = "Caut&#259;";
$locale['462'] = "Categorie:";
$locale['463'] = "Sorteaz&#259; dup&#259;:";
?>
